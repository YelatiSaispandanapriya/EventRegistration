import React from 'react'
import Form from './components/Form/Form'

export default function App() {
  return (
    <>
      <Form />
    </>
  )
}
